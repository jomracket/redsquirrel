This file is in the 'hostfs' folder in the
RedSquirrel directory.

You can add files and folder from Windows to
this folder and see then from with the 
emulator. Similarly you can create files from
within the emulator and access them from Windows.

You can access different folders by using the
hostfs configuration panel. These folders are
configured per model. This allows different 
boot structures to be installed for each model.

